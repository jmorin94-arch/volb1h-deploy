@echo off
setlocal
title VOLB1H Bot Setup
set "HOME_DIR=%LOCALAPPDATA%\VOLB1H"
echo.
echo  VOLB1H Bot Setup - preparing this computer (first run takes a few minutes)...
echo.
if not exist "%HOME_DIR%" mkdir "%HOME_DIR%"
copy /y "%~dp0bootstrap.py" "%HOME_DIR%\bootstrap.py" >nul
copy /y "%~dp0run.py" "%HOME_DIR%\run.py" >nul
set "PYEXE="
for /f "delims=" %%i in ('py -3.12 -c "import tkinter,sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%i"
if defined PYEXE goto havepy
for /f "delims=" %%i in ('py -3 -c "import tkinter,sys;assert sys.version_info>=(3,10);print(sys.executable)" 2^>nul') do set "PYEXE=%%i"
if defined PYEXE goto havepy
for /f "delims=" %%i in ('python -c "import tkinter,sys;assert sys.version_info>=(3,10);print(sys.executable)" 2^>nul') do set "PYEXE=%%i"
if defined PYEXE goto havepy
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if defined PYEXE goto havepy
echo  Installing Python (one time, about 2 minutes). Please wait...
curl -L -# -o "%TEMP%\python-3.12.10-amd64.exe" https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe
if errorlevel 1 goto dlfail
"%TEMP%\python-3.12.10-amd64.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_tcltk=1 Include_pip=1 Include_test=0
set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not exist "%PYEXE%" goto pyfail
:havepy
echo  Using Python: %PYEXE%
if not exist "%HOME_DIR%\.venv\Scripts\python.exe" "%PYEXE%" -m venv "%HOME_DIR%\.venv"
if not exist "%HOME_DIR%\.venv\Scripts\python.exe" goto venvfail
echo  Opening the setup window...
start "" "%HOME_DIR%\.venv\Scripts\pythonw.exe" "%HOME_DIR%\bootstrap.py"
exit /b 0
:dlfail
echo  Could not download Python. Check the internet connection and run this file again.
pause
exit /b 1
:pyfail
echo  Python did not install. Run this file again; if it fails twice, install Python 3.12 from python.org and retry.
pause
exit /b 1
:venvfail
echo  Could not create the program folder. Run this file again; if it fails twice, send a photo of this window to whoever gave you the link.
pause
exit /b 1
