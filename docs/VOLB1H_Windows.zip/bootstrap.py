"""VOLB1H setup for a Windows PC (the computer version of the phone setup page). Standard library only.

Paste the setup code from the setup page -> this window writes the keys, downloads git (MinGit), clones the
private bot repository with the read-only deploy key, installs the Python parts, puts the runner in the Startup
folder, turns off sleep, starts the Telegram remote, checks Tradier, loads price history and starts the bot.
Same stages and status words as the server install, so the phone gets the same messages.

Everything lives in %LOCALAPPDATA%\\VOLB1H (HOME): app/ (the repo), .venv/, mingit/, state/ (keys, config, DBs, logs).
Run again any time: paste a new code to redo the setup, or Repair to re-run with the saved keys."""
import os, sys, json, time, base64, struct, zipfile, shutil, threading, queue, subprocess, urllib.request
import tkinter as tk
from tkinter import ttk

HOME = os.path.dirname(os.path.abspath(__file__))
WIN = os.name == "nt"
APP, DATA, MINGIT = os.path.join(HOME, "app"), os.path.join(HOME, "state"), os.path.join(HOME, "mingit")
CONFIG, KEY, KNOWN_HOSTS = (os.path.join(DATA, n) for n in ("config.json", "deploy_key", "known_hosts"))
STATUS_FILE = os.path.join(DATA, "install_status")
STOP_FLAG = os.path.join(DATA, "bot_stopped")
HEARTBEAT = os.path.join(DATA, "supervisor.json")
PY = sys.executable.replace("pythonw.exe", "python.exe")
PYW = PY.replace("python.exe", "pythonw.exe") if WIN else PY
GIT = os.path.join(MINGIT, "cmd", "git.exe") if WIN else "git"
SSH = os.path.join(MINGIT, "usr", "bin", "ssh.exe") if WIN else "ssh"
MINGIT_URL = "https://github.com/git-for-windows/git/releases/download/v2.56.0.windows.1/MinGit-2.56.0-64-bit.zip"
GITHUB_HOST_KEY = "github.com ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOMqqnkVzrm0SdG6UOoqKLsabgH5C9okWi0dh2l9GKJl\n"
APP_NAME = "VOLB1H Bot"
STARTUP_VBS = os.path.join(os.environ.get("APPDATA", HOME), "Microsoft", "Windows", "Start Menu", "Programs", "Startup", f"{APP_NAME}.vbs")
FLAGS = getattr(subprocess, "CREATE_NO_WINDOW", 0)
FONT = ("Segoe UI", 11) if WIN else ("Helvetica", 12)
BIG = (FONT[0], FONT[1] + 6, "bold")
NEEDED = ("tradier_token", "telegram_token", "pair_code", "repo", "deploy_key_blob")


# ---- helpers ------------------------------------------------------------------------------------------------
def _s(b):
    return struct.pack(">I", len(b)) + b


def rebuild_key(blob, comment="volb1h"):
    """64-byte ed25519 blob (seed+public) from the setup page -> OpenSSH private key text (same as keyblob.py)."""
    sk = base64.urlsafe_b64decode(blob + "=" * (-len(blob) % 4))
    if len(sk) != 64:
        raise ValueError("the setup code's key is damaged")
    pub = sk[32:]
    pubkey = _s(b"ssh-ed25519") + _s(pub)
    chk = os.urandom(4)
    priv = chk + chk + _s(b"ssh-ed25519") + _s(pub) + _s(sk) + _s(comment.encode())
    pad = 1
    while len(priv) % 8:
        priv += bytes([pad]); pad += 1
    raw = b"openssh-key-v1\0" + _s(b"none") + _s(b"none") + _s(b"") + struct.pack(">I", 1) + _s(pubkey) + _s(priv)
    b64 = base64.b64encode(raw).decode()
    return "-----BEGIN OPENSSH PRIVATE KEY-----\n" + "\n".join(b64[i:i + 70] for i in range(0, len(b64), 70)) + "\n-----END OPENSSH PRIVATE KEY-----\n"


def decode_code(code):
    try:
        o = json.loads(base64.b64decode("".join(code.split())).decode())
    except Exception:
        raise ValueError("That is not a setup code. Copy the whole code from the setup page and paste it again.")
    missing = [k for k in NEEDED if not o.get(k)]
    if missing:
        raise ValueError("The setup code is incomplete (" + ", ".join(missing) + "). Copy it again from the setup page.")
    return o


def stage(name):
    os.makedirs(DATA, exist_ok=True)
    with open(STATUS_FILE, "w", encoding="utf-8") as f:
        f.write(name)


def run(cmd, env=None, timeout=900, cwd=None, on_line=None):
    e = dict(os.environ); e.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "PYTHONUNBUFFERED": "1"}); e.update(env or {})
    p = subprocess.Popen(cmd, cwd=cwd, env=e, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                         text=True, encoding="utf-8", errors="replace", creationflags=FLAGS)
    lines = []
    for line in p.stdout:
        lines.append(line.rstrip())
        if on_line:
            on_line(line.rstrip())
    p.wait(timeout=timeout)
    return p.returncode, "\n".join(lines)


def git_env():
    return {"GIT_SSH_COMMAND": f'"{SSH}" -i "{KEY}" -o IdentitiesOnly=yes -o UserKnownHostsFile="{KNOWN_HOSTS}" -o StrictHostKeyChecking=accept-new'}


def bot_env():
    return {"VOLB1H_CONFIG": CONFIG, "VOLB1H_DATA": DATA, "VOLB1H_HOST": "windows", "VOLB1H_GIT": GIT}


def heartbeat():
    try:
        with open(HEARTBEAT) as f:
            hb = json.load(f)
        return hb if time.time() - hb.get("ts", 0) < 30 else None
    except Exception:
        return None


def wait_for(cond, timeout, step=1.0):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if cond():
            return True
        time.sleep(step)
    return False


# ---- the install, step by step (runs in a thread; say() lines go to the window) ------------------------------
def install(code, say, repair=False):
    os.makedirs(DATA, exist_ok=True)
    if not repair:
        o = decode_code(code)
        stage("saving your keys")
        say("Saving your keys…")
        cfg = {"tradier_token": o["tradier_token"].strip(), "telegram_token": o["telegram_token"].strip(),
               "pair_code": str(o["pair_code"]), "size_frac": float(o.get("size_frac", 0.60)),
               "sleeve_sym": o.get("sleeve_sym", "SPY"), "sleeve_frac": float(o.get("sleeve_frac", 0.20))}
        if o.get("observe_only"):
            cfg["observe_only"] = True                                 # test installs: the bot never places an order
        old = {}
        try:
            with open(CONFIG) as f:
                old = json.load(f)
        except Exception:
            pass
        if old.get("tradier_token") == cfg["tradier_token"]:
            cfg["tradier_account"] = old.get("tradier_account")       # same account: keep what we learned before
        with open(CONFIG, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=1)
        with open(KEY, "w", newline="\n") as f:
            f.write(rebuild_key(o["deploy_key_blob"]))
        with open(KNOWN_HOSTS, "w", newline="\n") as f:
            f.write(GITHUB_HOST_KEY)
        with open(os.path.join(DATA, "repo.txt"), "w") as f:
            f.write(o["repo"])
        os.chmod(KEY, 0o600)
        if WIN:                                                        # ssh refuses a key other users could read
            for p in (KEY, CONFIG):
                subprocess.run(["icacls", p, "/inheritance:r", "/grant:r", f"{os.environ.get('USERNAME', '')}:F"],
                               capture_output=True, creationflags=FLAGS)
    with open(os.path.join(DATA, "repo.txt")) as f:
        repo = f.read().strip()

    if WIN and not os.path.exists(GIT):
        stage("downloading tools")
        say("Downloading git (40 MB, one time)…")
        zp = os.path.join(HOME, "mingit.zip")
        urllib.request.urlretrieve(MINGIT_URL, zp)
        shutil.rmtree(MINGIT, ignore_errors=True)
        with zipfile.ZipFile(zp) as z:
            z.extractall(MINGIT)
        os.remove(zp)
        if not os.path.exists(GIT):
            raise RuntimeError("git did not unpack")
        say("git ready.")

    stage("downloading the bot")
    if os.path.isdir(os.path.join(APP, ".git")):
        say("Updating the bot's code…")
        rc, outp = run([GIT, "-C", APP, "pull", "-q", "--ff-only", "origin", "main"], env=git_env())
    else:
        say("Downloading the bot's code…")
        shutil.rmtree(APP, ignore_errors=True)
        rc, outp = run([GIT, "clone", "-q", repo, APP], env=git_env())
    if rc != 0:
        raise RuntimeError("Could not download the bot: " + outp[-400:])
    say("Code downloaded.")

    stage("installing the bot's Python parts")
    say("Installing the bot's Python parts (a few minutes the first time)…")
    with open(os.path.join(APP, "install", "manifest.json")) as f:
        req = os.path.join(APP, json.load(f)["requirements"].replace("/", os.sep))
    rc, outp = run([PY, "-m", "pip", "install", "-q", "--disable-pip-version-check", "-r", req])
    if rc != 0:
        raise RuntimeError("Could not install the Python parts: " + outp[-400:])
    say("Python parts installed.")

    stage("starting the Telegram remote")
    say("Installing the start-at-login entry and turning off sleep…")
    with open(STOP_FLAG, "w") as f:                                    # bot stays down until history is loaded
        f.write("install")
    install_autostart()
    make_status_shortcut()
    start_runner()
    if not wait_for(lambda: heartbeat() is not None, 60):
        raise RuntimeError("The supervisor did not start. Send the file state\\supervisor.log to whoever gave you the link.")
    say("Telegram remote running — you can connect your phone now (the setup page shows how).")

    stage("checking Tradier")
    say("Checking Tradier…")
    rc, outp = run([PY, "seed.py", "account"], env=bot_env(), cwd=os.path.join(APP, "bot"))
    if rc != 0:
        raise RuntimeError("Tradier did not accept the key. Check it on web.tradier.com/user/api (Production, not Sandbox). "
                           + outp[-200:])
    say(outp.strip().splitlines()[-1] if outp.strip() else "Tradier OK.")

    stage("loading price history (about 2 minutes)")
    say("Loading price history (about 2 minutes)…")
    rc, outp = run([PY, "seed.py", "history"], env=bot_env(), cwd=os.path.join(APP, "bot"), on_line=say, timeout=1800)
    if rc != 0:
        raise RuntimeError("Price history did not load: " + outp[-300:])

    stage("starting the bot")
    say("Starting the bot…")
    try:
        os.remove(STOP_FLAG)
    except FileNotFoundError:
        pass
    if not wait_for(lambda: (heartbeat() or {}).get("bot_pid"), 90):
        raise RuntimeError("The bot did not start. Send the file state\\bot.log to whoever gave you the link.")
    stage("done")
    say("Done. The bot is running.")


def install_autostart():
    if not WIN:
        return
    os.makedirs(os.path.dirname(STARTUP_VBS), exist_ok=True)
    with open(STARTUP_VBS, "w") as f:
        f.write(f'CreateObject("WScript.Shell").Run """{PYW}"" ""{os.path.join(HOME, "run.py")}""", 0, False\r\n')
    for cmd in (["powercfg", "/change", "standby-timeout-ac", "0"],
                ["powercfg", "/change", "hibernate-timeout-ac", "0"],
                ["powercfg", "/setacvalueindex", "SCHEME_CURRENT", "SUB_BUTTONS", "LIDACTION", "0"],
                ["powercfg", "/setactive", "SCHEME_CURRENT"]):
        subprocess.run(cmd, capture_output=True, creationflags=FLAGS)


def make_status_shortcut():
    desk = os.path.join(os.path.expanduser("~"), "Desktop")
    st = os.path.join(APP, "install", "windows", "status.py")
    if WIN and os.path.isdir(desk):
        with open(os.path.join(desk, "VOLB1H Status.vbs"), "w") as f:
            f.write(f'CreateObject("WScript.Shell").Run """{PYW}"" ""{st}""", 0, False\r\n')


def start_runner():
    if heartbeat():
        return
    if WIN:
        subprocess.Popen(["wscript.exe", STARTUP_VBS], creationflags=FLAGS)
    else:
        subprocess.Popen([PY, os.path.join(HOME, "run.py")], cwd=HOME, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)


# ---- window ---------------------------------------------------------------------------------------------------
class Setup(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("VOLB1H Bot Setup"); self.geometry("720x560"); self.resizable(False, False)
        self.q = queue.Queue()
        f = ttk.Frame(self, padding=20); f.pack(fill="both", expand=True)
        ttk.Label(f, text="Set up the VOLB1H bot on this computer", font=BIG).pack(anchor="w")
        ttk.Label(f, text="Paste the setup code from the setup page (the one you got on your phone or in your browser), "
                          "then click Install. Keep this computer on, plugged in, and online on weekdays 9:30–4:00 New York time.",
                  font=FONT, wraplength=680, justify="left").pack(anchor="w", pady=(6, 10))
        self.box = tk.Text(f, height=4, font=("Consolas", 9), wrap="char"); self.box.pack(fill="x")
        row = ttk.Frame(f); row.pack(fill="x", pady=8)
        ttk.Button(row, text="Paste", command=self.paste).pack(side="left")
        self.btn = ttk.Button(row, text="Install", command=self.go); self.btn.pack(side="left", padx=8)
        if os.path.exists(CONFIG):
            self.rep = ttk.Button(row, text="Repair (keep my keys)", command=lambda: self.go(repair=True)); self.rep.pack(side="left")
        self.stage = ttk.Label(f, text="", font=FONT, wraplength=680, justify="left"); self.stage.pack(anchor="w", pady=(4, 2))
        self.log = tk.Text(f, height=13, font=("Consolas", 9), state="disabled"); self.log.pack(fill="x")
        self.after(150, self.pump)

    def paste(self):
        try:
            self.box.delete("1.0", "end"); self.box.insert("1.0", self.clipboard_get().strip())
        except Exception:
            self.stage.config(text="Nothing to paste: copy the setup code first.")

    def say(self, s):
        self.q.put(s)

    def pump(self):
        try:
            while True:
                s = self.q.get_nowait()
                if s.startswith("##"):
                    self.stage.config(text=s[2:].strip(), foreground="red" if s.startswith("##!") else "black")
                    if s.startswith("##!") or s.startswith("##OK"):
                        self.btn.config(state="normal")
                    continue
                self.log.config(state="normal"); self.log.insert("end", s + "\n"); self.log.see("end"); self.log.config(state="disabled")
        except queue.Empty:
            pass
        self.after(150, self.pump)

    def go(self, repair=False):
        code = self.box.get("1.0", "end").strip()
        if not repair and not code:
            self.stage.config(text="Paste the setup code first.", foreground="red"); return
        self.btn.config(state="disabled")
        self.stage.config(text="Working…", foreground="black")

        def work():
            try:
                install(code, self.say, repair=repair)
                self.say("##OK Setup finished ✅  Go back to the setup page and tap Connect my bot. You can close this window.")
            except Exception as e:
                try:
                    cur = open(STATUS_FILE, encoding="utf-8").read().strip()
                except Exception:
                    cur = "setup"
                if not cur.startswith("FAILED"):
                    stage(f"FAILED: {cur}")
                self.say(f"##! Setup stopped: {e}")
        threading.Thread(target=work, daemon=True).start()


if __name__ == "__main__":
    Setup().mainloop()
