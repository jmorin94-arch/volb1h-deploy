"""VOLB1H Windows runner (Startup folder entry). Tiny and never updated: keeps install/windows/supervisor.py from the
cloned repo running; the supervisor exits after it pulled new code and this starts the new one. Exit code 3 (another
supervisor is already running) ends this too; any other exit is retried forever, like systemd would."""
import os, sys, time, subprocess

HOME = os.path.dirname(os.path.abspath(__file__))
SUP = os.path.join(HOME, "app", "install", "windows", "supervisor.py")
PY = sys.executable.replace("pythonw.exe", "python.exe")
FLAGS = getattr(subprocess, "CREATE_NO_WINDOW", 0)

while True:
    t0 = time.time()
    try:
        code = subprocess.call([PY, SUP], cwd=HOME, creationflags=FLAGS, stdin=subprocess.DEVNULL,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        code = -1
    if code == 3:
        break                                   # another supervisor is already running
    time.sleep(30 if time.time() - t0 < 5 else 10)   # crashed at once (bad update, missing file): keep trying, slower
